/**
  ******************************************************************************
  * @file    bsp_timer2.c
  * @author  MCU��
  * @version V1.0
  * @date    2020-3-15
  * @brief   MODBUS ����
  ******************************************************************************
  * @attention
  *
  * ʵ��ƽ̨:STM32F013VE
  * ���ں�  :��Ƭ��������
  * �Ա�    :https://item.taobao.com/item.htm?id=527665566561
  *
  ******************************************************************************
  */ 

#include "bsp_timer2.h"

void timer2_init(uint16_t period)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
  TIM_DeInit(TIM2);
	TIM_TimeBaseStructure.TIM_Period = period;
  TIM_TimeBaseStructure.TIM_Prescaler = (1800 - 1);	
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
	TIM_Cmd(TIM2, ENABLE);

}

void timer2_nvic(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;	
	NVIC_Init(&NVIC_InitStructure);	
}


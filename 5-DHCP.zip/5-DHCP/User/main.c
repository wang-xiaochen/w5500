/**
  ******************************************************************************
  * @file    WIZnet MDK5 Project Template  ../main.c 
  * @author  WIZnet Software Team
  * @version V1.0.0
  * @date    2017-07-28
  * @brief   Main program body
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2017 WIZnet H.K. Ltd.</center></h2>
  ******************************************************************************
  */  

/* Includes ------------------------------------------------------------------*/
#include <stm32f10x.h>

#include "mcu_init.h"
#include "config.h"
#include "device.h"
#include "spi2.h"
#include "socket.h"
#include "w5500.h"
#include "at24c16.h"
#include "util.h"
#include "dhcp.h"
#include "string.h"
#include <stdio.h>

/****************************************************
��������		main
�βΣ�			��
����ֵ��		��
�������ܣ�	������
****************************************************/
extern uint8 txsize[];
extern uint8 rxsize[];

uint8 buffer[2048];/*����һ��2KB�Ļ���*/
  
int main()
{
  RCC_Configuration(); /* ���õ�Ƭ��ϵͳʱ��*/
	NVIC_Configuration();/* ����Ƕ���ж�����*/
	Systick_Init(72);/* ��ʼ��Systick����ʱ��*/
  GPIO_Configuration();/* ����GPIO*/ 
	Timer_Configuration();/*��ʱ����ʼ��*/
  USART1_Init(); /*��ʼ������ͨ��:115200@8-n-1*/
  at24c16_init();/*��ʼ��eeprom*/
  printf("W5500 EVB initialization over.\r\n");
  
  Reset_W5500();/*Ӳ����W5500*/
  WIZ_SPI_Init();/*��ʼ��SPI�ӿ�*/
  printf("W5500 initialized!\r\n");  
  
  set_default(); 	
  init_dhcp_client();

  while(1)
  {
		DHCP_run();
	}
}

/******************* (C) COPYRIGHT 2017 WIZnet H.K. Ltd. ****** END OF FILE ****/
